<?php

namespace App\Actions\Fortify;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Laravel\Fortify\Contracts\CreatesNewUsers;
use Laravel\Jetstream\Jetstream;

class CreateNewUser implements CreatesNewUsers
{
    use PasswordValidationRules;

    /**
     * Validate and create a newly registered user.
     *
     * @param  array<string, string>  $input
     */
// File: App\Actions\Fortify\CreateNewUser.php or similar

public function create(array $input)
{
    // ... validation code ...

    return DB::transaction(function () use ($input) {
        
        // 1. Admin Check Logic (Unang user ay 'admin')
        $userCount = \App\Models\User::count();
        $role = ($userCount === 0) ? 'admin' : $input['role'];

        // 2. Create the User
        $user = tap(\App\Models\User::create([
            'name' => $input['name'],
            'email' => $input['email'],
            'password' => Hash::make($input['password']),
            'role' => $role, // Gagamitin ang na-determine na role
        ]), function (\App\Models\User $user) use ($input) {
            
            // 3. Role-Based Record Creation
            
            // Para sa SELLER
            if ($user->role === 'seller') {
                \App\Models\Seller::create(['user_id' => $user->id]);
            }
            
            // Para sa CUSTOMER (IDAGDAG ITO)
            if ($user->role === 'customer') {
                // Ipalagay na mayroon kang \App\Models\Customer
                \App\Models\Customer::create(['user_id' => $user->id]);
            }
            
            // ... creation ng team/profile photo ...
        });

        return $user;
    });
}
}
