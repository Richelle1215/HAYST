<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Models\Product;
use App\Models\Category;
use Illuminate\Support\Facades\Auth;

class ProductController extends Controller
{
    /**
     * 1. INDEX: Ipakita ang listahan ng Products
     */
    public function index(Request $request)
    {
        $sellerId = Auth::id();

        // Kuhanin ang listahan ng categories na pag-aari ng seller
        $categories = Category::where('seller_id', $sellerId)->get();

        // Simulan ang query para sa products ng kasalukuyang seller
        $productsQuery = Product::where('seller_id', $sellerId)->with('category');
        
        // I-check kung may category filter sa URL
        $selectedCategory = $request->query('category');

        if ($selectedCategory && $selectedCategory !== 'all') {
            
            // Hanapin ang Category ID batay sa pangalan
            $categoryFilter = Category::where('name', $selectedCategory)->first();

            if ($categoryFilter) {
                $productsQuery->where('category_id', $categoryFilter->id);
            }
        }

        // Kuhanin ang final list ng products
        $products = $productsQuery->orderBy('created_at', 'desc')->get();

        // Ipasa ang data sa view
        return view('seller.products.index', [
            'products' => $products,
            'categories' => $categories, 
            'selectedCategory' => $selectedCategory 
        ]);
    }

    /**
     * 2. CREATE: Ipakita ang form para gumawa ng bagong Product
     */
    public function create()
    {
        // Kuhanin lang ang categories ng kasalukuyang seller para sa dropdown
        $categories = Category::where('seller_id', Auth::id())->get();
        
        // I-return ang view ng creation form
        return view('seller.products.create', compact('categories')); 
    }


    /**
     * 3. STORE: I-save ang bagong Product (FIXED)
     */
public function store(Request $request)
{
    // 1. Validation (Naglalaman na ng 'stock')
    $validated = $request->validate([
        'name' => 'required|string|max:255',
        'description' => 'required|string',
        'price' => 'required|numeric|min:0',
        'stock' => 'required|integer|min:0', // Ito ang kinakailangan mong field
        'category_id' => 'required|exists:categories,id',
        'image' => 'nullable|image|max:2048',
    ]);
    
    // 2. Add seller_id (Dapat ito ang susunod)
    $validated['seller_id'] = Auth::id();
    
    // 3. Handle Image Upload
    if ($request->hasFile('image')) {
        $path = $request->file('image')->store('products', 'public');
        $validated['image'] = $path; // I-update ang validated data
    } else {
         // Kung walang image, hayaan lang itong 'null' base sa 'nullable' validation
         // Tiyakin na ang 'image' column ay pwedeng maging NULL sa database.
         // Kung may 'image' key na nanggaling sa validation, hayaan lang, Laravel na ang bahala
         // kung 'nullable' ito. Kung hindi, maaari mong manual na i-set:
         $validated['image'] = null;
    }
    
    // 4. I-save ang produkto
    Product::create($validated); 
    
    return redirect()->route('seller.products.index')
                     ->with('success', 'Product saved successfully.');
}

    /**
     * 4. SHOW: Ipakita ang detalye ng isang Product
     */
    public function show(Product $product)
    {
        // Check if the product belongs to the authenticated seller (Security)
        if ($product->seller_id !== Auth::id()) {
            abort(403); // Forbidden
        }

        $categories = Category::all(); 
        return view('seller.products.show', compact('product', 'categories'));
    }


    /**
     * 5. EDIT: Ipakita ang form para i-edit ang Product
     */
    public function edit(Product $product)
    {
        // Check if the product belongs to the authenticated seller (Security)
        if ($product->seller_id !== Auth::id()) {
            abort(403); // Forbidden
        }
        
        // Kuhanin ang categories ng seller
        $categories = Category::where('seller_id', Auth::id())->get();
        
        // Tiyakin na mayroon kang view: resources/views/seller/products/edit.blade.php
        return view('seller.products.edit', compact('product', 'categories'));
    }

    /**
     * 6. UPDATE: I-update ang Product
     */
    public function update(Request $request, Product $product)
    {
        // Check if the product belongs to the authenticated seller (Security)
        if ($product->seller_id !== Auth::id()) {
            abort(403); // Forbidden
        }

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'price' => 'required|numeric|min:0',
            'stock' => 'required|integer|min:0',
            'category_id' => 'required|exists:categories,id',
            'image' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
        ]);
        
        // Update product data with validated fields
        $product->fill($validated);

        // Handle image upload
        if ($request->hasFile('image')) {
            // Delete old image if exists
            if ($product->image && Storage::disk('public')->exists($product->image)) {
                Storage::disk('public')->delete($product->image);
            }

            // Store new image
            $path = $request->file('image')->store('products', 'public');

            // Save path to DB
            $product->image = $path;
        }

        $product->save();

        return redirect()
            ->route('seller.products.index')
            ->with('success', 'Product updated successfully!');
    }

    /**
     * 7. DESTROY: Burahin/I-delete ang Product
     */
    public function destroy(Product $product)
    {
        // Check if the product belongs to the authenticated seller (Security)
        if ($product->seller_id !== Auth::id()) {
            abort(403); // Forbidden
        }

        // Delete image from storage
        if ($product->image) {
            Storage::disk('public')->delete($product->image);
        }

        // Delete record from database
        $product->delete();
        
        return redirect()->route('seller.products.index')
                         ->with('success', 'Product deleted successfully.');
    }
}