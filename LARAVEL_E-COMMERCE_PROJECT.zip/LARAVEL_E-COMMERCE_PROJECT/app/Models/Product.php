<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
protected $fillable = [
    'name',
    'description',
    'price',
    'image',
    'stock',
    'category_id',
    'seller_id',
];

        public function category()
        {
            return $this->belongsTo(Category::class);
        }
        public function seller()
{
    return $this->belongsTo(Seller::class);
}

}
