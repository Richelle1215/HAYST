<?php
    if (Auth::user()->role !== 'seller') {
        abort(403, 'Unauthorized');
    }
?>



<?php $__env->startSection('content'); ?>
    <div class="container py-5 text-center">
        <h1>Welcome, <?php echo e(Auth::user()->name); ?>!</h1>
        <p>You are logged in as <strong><?php echo e(Auth::user()->role); ?></strong>.</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Richelle Morada\Downloads\INFO ABOUT LARA\HAYST\LARAVEL_E-COMMERCE_PROJECT\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>