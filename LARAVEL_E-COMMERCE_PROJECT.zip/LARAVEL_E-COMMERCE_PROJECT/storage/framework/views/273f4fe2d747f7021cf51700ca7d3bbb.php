<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>LUMIÈRE</title>

    <script src="https://cdn.tailwindcss.com"></script>
<script>
    // Disable back navigation completely
    if (window.history && window.history.pushState) {
        window.history.pushState(null, null, window.location.href);
        window.onpopstate = function () {
            window.history.pushState(null, null, window.location.href);
        };
    }
</script>



    <style>
        /* Define colors based on the Elle Fashion image (muted rose/brown for accent) */
        :root {
            --primary-text: #222222; 
            --secondary-text: #666666; 
            --accent-color: #8C5B56; /* Muted Rose/Brown from the image's buttons */
            --light-bg: #F5F5F5; /* Light grey background */
        }
        
        /* Importing an elegant serif font (Playfair Display) for titles and a clean sans-serif (Inter) for body text */
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&family=Inter:wght@100..900&display=swap');
        
        body {
            font-family: 'Inter', sans-serif; /* Default for body text */
            background-color: var(--light-bg); 
            color: var(--primary-text);
        }
        
        .font-serif-elegant {
            font-family: 'Playfair Display', serif; /* Custom class for high-fashion headings */
        }

        /* Custom Tailwind classes for the new style */
        .text-accent { color: var(--accent-color); }
        .bg-accent { background-color: var(--accent-color); }
        .hover\:bg-accent-dark:hover { background-color: #7A4E49; }
        
        /* Custom height utility for better responsiveness on the hero section to fit the screen */
        .h-hero {
            height: 50vh; 
            max-height: 600px; 
        }
        @media (min-width: 640px) {
            .h-hero {
                height: 70vh; 
            }
        }
    </style>

    <?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php endif; ?>
</head>
<body class="antialiased">

    <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


       <div class="py-6 sm:py-12 bg-gray-100">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="p-4 sm:p-0">
                
                <h1 class="text-3xl font-bold mb-6 text-gray-800">
                    <?php echo e(isset($currentCategory) ? $currentCategory->name . ' Products' : 'All Products'); ?>

                </h1>
                
                <div class="mb-8 p-4 bg-white shadow-md rounded-lg">
                    <h3 class="text-xl font-semibold mb-2 text-gray-700">Filter by Category</h3>
                    <div class="flex flex-wrap gap-2">
                        <a href="<?php echo e(route('products.index')); ?>" class="px-3 py-1 text-sm bg-indigo-100 text-indigo-700 rounded-full hover:bg-indigo-500 hover:text-white transition">All Products</a>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('products.filter', $category)); ?>" class="px-3 py-1 text-sm bg-gray-200 text-gray-800 rounded-full hover:bg-indigo-500 hover:text-white transition">
                                <?php echo e($category->name); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="bg-white shadow-lg rounded-lg overflow-hidden transition transform hover:scale-105">
                            
                            <div class="h-48 overflow-hidden">
                                <?php if($product->image): ?>
                                    <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-full object-cover">
                                <?php else: ?>
                                    <div class="w-full h-full bg-gray-200 flex items-center justify-center text-gray-500">No Image</div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="p-4">
                                <h2 class="text-xl font-semibold text-gray-800 truncate"><?php echo e($product->name); ?></h2>
                                <p class="text-indigo-600 font-bold mt-1">P<?php echo e(number_format($product->price, 2)); ?></p>
                                <p class="text-sm text-gray-500 mt-1">Stock: <?php echo e($product->stock); ?></p>
                                <a href="<?php echo e(route('products.show', $product)); ?>" class="mt-3 block text-center bg-indigo-500 text-white py-2 rounded hover:bg-indigo-600 transition">
                                    View Details
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="col-span-4 text-center text-gray-500 bg-white p-6 rounded-lg shadow">No products found. Please log in to the Seller Panel to add items.</p>
                    <?php endif; ?>
                </div>

                <div class="mt-8">
                    <?php echo e($products->links()); ?>

                </div>
            </div>
        </div>
    </div>
  
   
    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html><?php /**PATH C:\Users\Richelle Morada\Downloads\INFO ABOUT LARA\HAYST\LARAVEL_E-COMMERCE_PROJECT\resources\views/store/index.blade.php ENDPATH**/ ?>