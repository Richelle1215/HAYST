
<header class="bg-white shadow-md sticky top-0 z-50">
    
    <div class="max-w-screen-2xl mx-auto px-10 lg:px-16"> 
        
        
        <div class="h-20 flex items-center justify-between">
            
            
            <div class="flex items-center text-sm font-semibold tracking-wider uppercase flex-shrink-0">
                
                
                <div class="mr-12"> 
                    <img
                        src="<?php echo e(asset('image/logo/blacktext-logo.png')); ?>" 
                        alt="Brand Logo"
                        class="h-10 w-auto" 
                    >
                </div>
                
                
                <div class="flex items-center space-x-8"> 
                    <a href="#" class="text-gray-700 hover:text-[#8C5B56] transition">CATEGORIES</a>
                    <a href="#" class="text-gray-700 hover:text-[#8C5B56] transition">NEW ARRIVALS</a>
                    <a href="#" class="text-gray-700 hover:text-[#8C5B56] transition">SALE</a>
                </div>
            </div>

            
            
            <div class="w-2/5 flex justify-center mx-12"> 
                <div class="relative w-full max-w-md">
                    <input 
                        type="search" 
                        placeholder="Search for clothes, bags, and more..." 
                        class="w-full pl-5 pr-12 py-2 border border-gray-300 rounded-lg text-base focus:ring-[#8C5B56] focus:border-[#8C5B56] transition"
                    >
                    
                    
                    <button type="submit" 
                        class="absolute right-0 top-0 h-full w-10 bg-[#8C5B56] hover:bg-[#7A4E49] text-white rounded-r-lg flex items-center justify-center font-bold text-xl transition"
                    >
                        &#x1F50D; 
                    </button>
                </div>
            </div>

            
            <div class="flex items-center space-x-4 flex-shrink-0">
                
                
                <a href="#" class="text-2xl text-gray-700 hover:text-[#8C5B56] transition mr-3">&#x1F6D2;</a> 
                
                
                <div class="h-6 w-px bg-gray-300"></div>

                
                    <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                            <?php
                                $role = Auth::user()->role ?? 'customer';
                            ?>

                            <?php if($role === 'admin'): ?>
                                <a href="<?php echo e(route('admin.dashboard')); ?>" class="text-sm font-semibold text-gray-700 hover:text-[#8C5B56] transition ml-2">
                                    Admin Dashboard
                                </a>
                            <?php elseif($role === 'seller'): ?>
                                <a href="<?php echo e(route('seller.dashboard')); ?>" class="text-sm font-semibold text-gray-700 hover:text-[#8C5B56] transition ml-2">
                                    Seller Dashboard
                                </a>
                            <?php else: ?>
                                <a href="<?php echo e(route('dashboard')); ?>" class="text-sm font-semibold text-gray-700 hover:text-[#8C5B56] transition ml-2">
                                    My Dashboard
                                </a>
                            <?php endif; ?>

                            <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                    class="text-sm font-semibold text-white px-3 py-1 rounded transition bg-red-600 hover:bg-red-700 ml-2">
                                    LOGOUT
                                </button>
                            </form>
                        <?php else: ?>
                            
                            <a href="<?php echo e(route('login')); ?>"
                                class="text-sm font-semibold text-gray-700 hover:text-[#8C5B56] transition ml-2">
                                LOGIN
                            </a>

                            <?php if(Route::has('register')): ?>
                                
                                <a href="<?php echo e(route('register')); ?>"
                                    class="text-sm font-semibold text-white px-3 py-1 rounded transition bg-[#8C5B56] hover:bg-[#7A4E49] ml-2">
                                    REGISTER
                                </a>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
            </div>
            
        </div>
        
    </div>
</header><?php /**PATH C:\Users\Richelle Morada\Downloads\INFO ABOUT LARA\HAYST\LARAVEL_E-COMMERCE_PROJECT\resources\views/partials/header.blade.php ENDPATH**/ ?>