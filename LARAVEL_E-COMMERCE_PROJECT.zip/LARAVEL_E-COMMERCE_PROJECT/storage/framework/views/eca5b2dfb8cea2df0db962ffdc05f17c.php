<?php $__env->startSection('content'); ?>
<div class="bg-white shadow rounded-lg p-8">
    <h1 class="text-3xl font-bold text-gray-800 mb-4">Welcome to Your Seller Dashboard 🎉</h1>
    <p class="text-gray-600">
        Manage your products, orders, and profile using the sidebar on the left.
    </p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('seller.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Richelle Morada\Downloads\INFO ABOUT LARA\HAYST\LARAVEL_E-COMMERCE_PROJECT\resources\views/seller/dashboard.blade.php ENDPATH**/ ?>